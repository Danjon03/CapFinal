function loadSubTopBar(menuBarTitle) {
    // 1. Create the left section
    const leftDiv = document.createElement('div');
    leftDiv.classList.add('top-bar-section', 'left');
    
    //Adding the back button
    const backBtn = document.createElement('button');
    backBtn.textContent = '← Back';
    // Either set the onclick attribute:
    backBtn.setAttribute('onclick', "window.location.href='../index.html'");
    // Append into the left section
    leftDiv.appendChild(backBtn);


    // 2. Create the center section
    const centerDiv = document.createElement('div');
    centerDiv.classList.add('top-bar-section', 'center');

    const titleP = document.createElement('p');
    titleP.classList.add('top-title');
    titleP.textContent = menuBarTitle;
    centerDiv.appendChild(titleP);

    // 3. Create the right section
    const rightDiv = document.createElement('div');
    rightDiv.classList.add('top-bar-section', 'right');

    const logoutBtn = document.createElement('button');
    logoutBtn.classList.add('logout-btn');
    logoutBtn.textContent = 'Log Out';
    logoutBtn.onclick = logout;
    rightDiv.appendChild(logoutBtn);

    // 4. Append all sections to the top-bar container
    const topBar = document.querySelector('.top-bar');
    if (!topBar) {
        console.error('No element with class .top-bar found');
        return;
    }
    topBar.append(leftDiv, centerDiv, rightDiv);
}

function loadMenuTopBar() {
    // 1. Create the left section
    const leftDiv = document.createElement('div');
    leftDiv.classList.add('top-bar-section', 'left');
    // (you can append child nodes to leftDiv here if needed)

    // 2. Create the center section
    const centerDiv = document.createElement('div');
    centerDiv.classList.add('top-bar-section', 'center');

    const titleP = document.createElement('p');
    titleP.classList.add('top-title');
    titleP.appendChild(document.createTextNode('Welcome '));


    const rawUser = localStorage.getItem('loggedInUserID');
    const user = JSON.parse(rawUser);
    const name = user.firstName;

    //get the logged in user's name to put in the top
    const userSpan = document.createElement('span');
    userSpan.id = 'username';
    userSpan.textContent = name;
    titleP.appendChild(userSpan);

    titleP.appendChild(document.createTextNode('!'));
    centerDiv.appendChild(titleP);

    // 3. Create the right section
    const rightDiv = document.createElement('div');
    rightDiv.classList.add('top-bar-section', 'right');

    const logoutBtn = document.createElement('button');
    logoutBtn.classList.add('logout-btn');
    logoutBtn.textContent = 'Log Out';
    logoutBtn.onclick = logout;
    rightDiv.appendChild(logoutBtn);

    // 4. Append all sections to the top-bar container
    const topBar = document.querySelector('.top-bar');
    if (!topBar) {
        console.error('No element with class .top-bar found');
        return;
    }
    topBar.append(leftDiv, centerDiv, rightDiv);
}

function logout()
{
    localStorage.clear();
    window.location.href = "./login.html";
}